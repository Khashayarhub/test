# from django.forms import forms, ModelForm
# from .models import Appointment
#
#
# class AppointmentForm(ModelForm):
#     class Meta:
#         model = Appointment
#         fields = ['name', 'email', 'phone_number', 'date' , 'time']